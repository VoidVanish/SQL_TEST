

#                                **HIVE**

#                         今日内容和目标

- [x] 了解HIVE作用
- [x] 掌握HIVE使用语法
- [x] 掌握内部表外部表区别
- [x] 掌握DDL语法

# **一、HIVE简介**
- hive：由Facebook开源用于解决海量结构化数据的统计工具。
- hive是基于hadoop的一个数据仓库工具，可以将结构化的数据文件映射为一张表，并提供类SQL查询功能。
# **二、HIVE本质**
- hive的本质是将HQL(HiveSQL)转化成MapReduce程序。
- hive处理的数据存储在HDFS
- hive分析数据底层实现是MapReduce
- 执行程序运行在Yarn
# **三、HIVE优缺点**
**优点:**

- 操作接口采用类SQL语法，提供快速开发能力(简单，易上手)
- 避免去写MapReduce，减少开发人员的学习成本
- hive优势在于处理大数据，对于处理小数据没有优势，因为hive执行延迟较高
- hive支持用户自定义函数，用户可以根据自己的需求来实现自己的函数

**缺点:**

- hive执行延迟高，因此常用于数据分析，对实时性要求不高的场合
- hive的HQL表达能力有限

# **四、HIVE与数据库比较**

**1、查询语言** 
针对hive的特性设计了类SQL的查询语言，熟悉SQL的开发者可以方便的使用hive

**2、数据更新**
hive是针对数据仓库应用设计的，而数仓的内容读多写少，因此，hive中不建议对数据的改写，所有数据加载时确定好而数据库中数据通常是需要修改，因此使用insert into添加数据，update修改数据

**3、执行的延迟**
hive查询时由于没有索引，需要扫描整个表，因此延迟较高。另一个导致hive延迟较高的因素是MapReduce。

**4、数据规模**
hive海量数据的支持，对应数据库处理数据量规模较小。

# **五、HIVE操作**

**1.hive启动**

```hive
--通过命令启动hive(直接在交互串口输入hive)
hive

--通过绝对路径启动（进入该路径下运行hive启动文件）
cd /opt/module/apache-hive-2.1.1-bin/bin/hive
```
**2.hive退出**

```hive
--输入exit退出
exit;
--输入quit退出
quit;
```
**3.常用交互命令**
```hive
-- -e 在非hive交互窗口下运行hivesql
hive -e "select * from test.emp;"

-- -f 讲hivesql封装到文档中运行
vim hivef.sql -- 编辑hivesql文件
select * from test.emp;
--调用该文件
hive -f /home/hadoop/123/hivef.sql >/home/hadoop/123/234/hivef.txt
```

4.hive交互窗口里操作HDFS

```hive
-- 在hive窗口中使用dfs可以直接操作hdfs
hive (default)> dfs -ls /test/;
```

# **六、HIVE数据类型**

**1.基本数据类型:**

| 类型      | 长度                                       |
| --------- | :----------------------------------------- |
| TINYINT   | 一字节的有符号整数，范围从 -128 到 127     |
| SMALLINT  | 二字节的有符号整数，范围从 -32768 到 32767 |
| INT       | 四字节的有符号整数                         |
| BIGINT    | 八字节的有符号整数                         |
| BOOLEAN   | 布尔类型，true或者false                    |
| FLOAT     | 四字节单精度浮点数                         |
| DOUBLE    | 八字节双精度浮点数                         |
| STRING    | 字符串                                     |
| DATE      | 日期                                       |

**数据类型演示:**

```hive
--建表
hive (default)>
create table emp1(empno int, ename string,job string, sal double);

--插入数据
hive (default)>
insert into emp1 values
(7788,'scott','manager',3000),(7839,'king','clerk',8000),
(7369,'smith','clerk',6000);

```

**2.集合数据类型:**

```hive
数组（ARRAY）：--一组具有相同类型的元素集合。
映射（MAP）：--一组键值对的集合。
结构体（STRUCT）：--可以包含不同类型的字段，类似于C语言中的结构体。
```

**数据类型实例演示：**

```hive
-- 第一步 切换到使用的对应数据库
show databases;
use test;
--第二步 使用建表文档中的建表语句创建表格
create table
l_test ( name string,
friends array<string>,
children map<string, int>,
address struct<street:string, city:string>
)
row format delimited fields terminated by ','
collection items terminated by '_'
map keys terminated by ':'
lines terminated by '\n';

-- 第三步 创建数据文件 test.txt
vim test.txt

fulaoshi,lilaoshi_luolaoshi,xiaofu:6_xiaofufu:5,ruyilu_guangzhou
lilaoshi,fulaoshi_luolaoshi,xiaoli:7,ruyilu_guangzhou

-- 第四步 导数据进入test.l_test表
load data local inpath '/home/hadoop/123/test.txt' into table l_test;

--第五步 查看表数据
select * from l_test;

--通过查寻语句显示数据类型
array(val1,val2,...)
map(key1, value1, key2, value2,...)
struct(val1, val2, val3,...)
--sql
select
array('xiaoming','xiaoli') 
,map('zhun','bei','xia','ke'),struct('aihao','rap');
```

**3.类型转化**

**隐式转换:**
```hive
--隐式类型转换规则  
1.任何整数类型都可以隐式转换为一个范围更广的类型，如TINYINT可以转换成INT，INT可以转换成BIGINT
2.所有整数类型，FLOAT和STRING(数字)类型都可以隐式转换成DOUBLE
3.TINYINT，SMALLINT，INT都可以转换成FLOAT
4.BOOLEAN类型不能转换成任何其他类型
```
**显式转换:**  

```hive
cast('1' as int) --通常使用在数据清洗时
--使用案例
select '1'+2,cast('1' as int)+2;
```
# **七、DDL数据定义** 语言

## **一、数据库**

**1.创建数据库**

```hive
-- 创建数据库
create database test_2;

-- if not exists 判断数据库是否存在再创建
create database if not exists test_2;

-- location 指定HDFS路径创建hive数据库 
create database test_loc location '/test_loc.db';
```
**2.查看数据库**

```hive
-- 展示所有数据库
show databases;

-- 展示所有以t开头的数据库 *表示任意个任意字符,|表示或者
show databases like 't*';

-- 查看数据路信息
desc database test;

--查看更多信息
desc database extended test;
```

**3.修改数据库**

```hive
--修改location(储存路径,支队后续新表格生效) 
ALTER DATABASE 数据库名 SET LOCATION hdfs路径;

--修改数据库参数
alter database test_2 set dbproperties ('createtime'='20240725');
```

**4.删除数据库**

```hive
-- 删除空数据库
drop database test_2;

-- if exists 判断数据库是否存在然后执行删除
drop database if exists test_2;

-- 如果库不为空，强制删除		
drop database test_loc cascade;
```
**5.声明当前使用数据库**

```hive
use databasename；
```

## **二、表格**

**1.创建表**

```hive
create table if not exists
external --外部表
comment --注释
partitioned by --分区
clustered by --分桶
sorted by --对桶中的数据排序*****
row format delimited fields terminated by ','  ---指定列分隔符
collection items terminated by '_' --指定MAP STRUCT ARRAY 的数据分隔符
map keys terminated by ':'--指定MAP中key和value的分隔符
lines terminated by '\n' --指定行分隔符
stored as 指定文件类型：
--1.textfile(文本)
--2.rcfile(列式存储格式文件)
--3.sequencefile(二进制序列文件)
location --指定表在HDFS上的存储位置
```

**2.根据查寻结果建表**

```hive
as --后跟查询语句，根据查询结果创建表
create table emp2 as select * from emp;
```

**3.复制表结构**

```hive
like --允许用户复制现有表的结构，但不复制数据
create table emp3 as emp2;
```

**4.查看表**

```hive
--展示当前数据下所有表格
show tables;

--查看表信息
desc emp2;

--查看表详细信息
desc formatted emp2;
```
**5.清空表**
```hive
truncate table emp1;
--truncate只能清空管理表，不能删除外部表中数据
```

**6.删除表**
```hive
--if exists 如果表格存在就删除表
drop  table if exists emp1;
```

## **三、内部表与外部表**

**1.管理表(内部表)**

默认创建的表都是管理表(内部表)。hive会控制着数据的生命周期，当我们删除一个管理表(内部表)时，hive会删除这个表中的数据。管理表不适合与其他工具共享数据。

```hive
--第一步 创建普通表(默认内部表)
create table if not exists
hsstd (id int, name string)
row format delimited fields terminated by '\t'
stored as textfile	

--第二步 准备数据文件 注意列分隔符
vim hsstd.txt
1       hs001
2       hs002
3       hs003
4       hs004
5       hs005
6       hs006
7       xiaoqiang
8       xiaomei
9       azhen
10      aqiang

--第三步 将数据导入进表格
load data local inpath '/home/hadoop/123/hsstd.txt' into table hsstd;

--第四步 查看表格类型
desc formatted hsstd;
/*
OwnerType: 拥有者类型
Location: : 储存位置
Table Type:表格类型 MANAGED_TABLE 管理表
*/

--第五步 删除表格，发现hdfs数据文件也被删除
drop table hsstd;
```

**2.外部表**

因为表外部表，所以hive并非认为其完全拥有这份数据，删除该表并不会删掉这份数据，不过描述表的元数据会被删掉。

```hive
--第一步 创建外部表
create external table if not exists --external外部表
dept_2 (deptno int,
dname string,
loc string)
row format delimited fields terminated by '\t';

--第二步 编辑数据文件(linux本地)
vim dept_2.txt
1	10	ACCOUNTING	NEW YORK
2	20	RESEARCH	DALLAS
3	30	SALES	CHICAGO
4	40	OPERATIONS	BOSTON

--第三步 导入数据到表格
load data local inpath '/home/hadoop/123/dept_2.txt' into table dept_2;

--第四步 查寻表格类型
desc formatted dept_2;

--第五步 删除外部表
drop table dept_2;
--元数据会删除但是真实数据会保留在hdfs上
--这时候在创建一张表名一样的表格,无论是外部表还是内部表都能使用之前外部表的真实数据
```

**3.内外部表相互转换**

```hive
--内部表转外部表
alter table hsstd set tblproperties('EXTERNAL'='TRUE');

--外部表转内部表
alter table hsstd set tblproperties('EXTERNAL'='FALSE');
```

## **四、修改表**

```hive
--添加列
	alter table hsstd add columns (age int);
	
--更新列
	alter table hsstd change column age age2 string;
	
--替换列名 替换表格中所有字段
	alter table hsstd replace columns (id int, name2 string, age2 string);
```
