#                 **HIVE(第二天)**

#                         今日内容和目标

- [x] 掌握DML语法结构
- [x] 掌握DQL语法结构

# **一、DML数据操作**

## 1.数据导入load

**load data：表示加载数据**
**local：表示从本地加载到hive表，否则从HDFS加载到hive**
**inpath:加载数据的路径**
**overwrite：覆盖表中已有数据，否则追加**
**into table：表示加载到哪张表**
**partition：表示上传到指定分区**

```hive
--加载本地数据到hive
load data local inpath '/home/hadoop/123/hsstd.txt' into table test.hsstd;

--上传本地文件到HDFS
(hive)dfs -put /home/hadoop/123/hsstd.txt /st;
(linux)hadoop fs -put /home/hadoop/123/hsstd.txt /st;

--加载HDFS的文件到hive表中   剪切效果  源文件会消失
load data inpath '/st/hsstd.txt' into table test.hsstd;

--加载数据使用overwrite覆盖表中已有数据
load data local inpath '/home/hadoop/123/hsstd.txt' overwrite into table test.hsstd;
```

## **2.插入数据(insert)**

```hive
--insert into追加 将新增的数据保存在新的数据文件下
insert into table hsstd values (11,'hs11'),(12,'hs12');

--insert overwrite覆盖 清空原有的所有数据文件,然后新增一个数据文件
insert overwrite table hsstd select id,name from hsstd where id<8;

--overwrite搭配values使用
insert overwrite table hsstd values(10,'aa');
```

## **3.多表(多分区)插入模式**

**实例：**

```hive
from dept_2  --数据来源表
insert overwrite table dept_3  --要新增数据的表
select * where deptno = 10 --查寻出什么数据就新增什么数据
insert overwrite table dept_4
select * where deptno = 20; --可以同时向N张表新增数据
```

## **4.import导入(空表或不存在的表)**

只有export导出的表目录才能使用import
```hive
--先export导出现有表
export table test.hsstd to '/tmp/hsstd_dc2';

--根据1中导出的目录，import导入新的表
import table hsstd_5 from '/tmp/hsstd_dc2';
```
## **5.数据导出**

### **1.insert导出**

**(1)将查询结果导出到Linux本地**

```hive
insert overwrite local directory --insert导出到Linux本地
'/home/hadoop/123/hsstd_dc3' --导出路径(目录)
select * from hsstd;  --查寻语句
```
**(2)将查询结果格式化导出到Linux本地**
```hive
insert overwrite local directory
'/home/hadoop/123/hsstd_dc4'
row format delimited fields terminated by '\t'--加一个分隔符
select * from hsstd;
```
**(3)将查询结果导出到HDFS**
```hive
insert overwrite directory --local删掉就好
'/st/hsstd_dc6' --HDFS的路径
row format delimited fields terminated by '\t'
select * from hsstd;
```
### **2.export导出到HDFS上**

export导出语句可将表的数据和元数据信息一并到处的HDFS路径，import可将export导出的内容导入hive，表的数据和元数据信息都会恢复。export和import可用于两个hive数据迁移

```hive
export table test.hsstd to '/tmp/hsstd_dc2';
```
# **二、DQL数据查询语句**

## **一.基本查询**

**数据准备:**

```hive
--创建emp表
create table if not exists
emp (empno string,
ename string,
job string,
mgr string,
hiredate string,
sal double,
comm double,
deptno string)
row format delimited fields terminated by '\t' ;

--创建数据文件 注意分隔符
vim emp.txt
7369	SMITH	CLERK	7902	1980/12/17	800.00		20
7499	ALLEN	SALESMAN	7698	1981/2/20	1600.00	300.00	30
7521	WARD	SALESMAN	7698	1981/2/22	1250.00	500.00	30
7566	JONES	MANAGER	7839	1981/4/2	2975.00		20
7654	MARTIN	SALESMAN	7698	1981/9/28	1250.00	1400.00	30
7698	BLAKE	MANAGER	7839	1981/5/1	2850.00		30
7782	CLARK	MANAGER	7839	1981/6/9	2450.00		10
7788	SCOTT	ANALYST	7566	1987/4/19	3000.00		20
7839	KING	PRESIDENT		1981/11/17	5000.00		10
7844	TURNER	SALESMAN	7698	1981/9/8	1500.00	0.00	30
7876	ADAMS	CLERK	7788	1987/5/23	1100.00		20
7900	JAMES	CLERK	7698	1981/12/3	950.00		30
7902	FORD	ANALYST	7566	1981/12/3	3000.00		20
7934	MILLER	CLERK	7782	1982/1/23	1300.00		10

--将数据文件导入emp表
load data local inpath '/home/hadoop/123/emp.txt' into table emp;

--创建dept表
create table if not exists
dept (deptno int,
dname string,
loc string)
row format delimited fields terminated by '\t' ;

--创建数据文件
vim dept.txt
10	ACCOUNTING	NEW YORK 
20	RESEARCH	DALLAS
30	SALES	CHICAGO
40	OPERATIONS	BOSTON

--将数据文件导入dept表
load data local inpath '/home/hadoop/123/dept.txt' into table dept;
```

**1.全表查询**
```hive
select * from emp;
```
**2.特定列查询**
```hive
select empno,ename from emp;
注意：
(1)大小写不敏感
(2)SQL可以写在一行或者多行
(3)关键字不能被缩写也不能分行
(4)各子句一般分行写
(5)使用缩进提高语句可读性
```
**3.列别名**
```hive
select empno as abc ,name from emp;
--字段名  AS  别名
```
**4.算术运算符**
```hive
-- + 加 - 减 * 乘 / 除 % 求余
select sal + 10000 from emp;
--求余
select 10 % 3;
```
**5.where语句**
```hive
--查寻工资大于1000的员工信息
select * from emp where sal > 1000;
--where写在from后面 
```
**6.比较运算符**
```hive
A=B
A<=>B 如果A和B都为NULL则返回TRUE，如果一边为NULL返回FALSE
A<>B,A!=B
A<B
A<=B
A>B
A>=B
A NOT BETWEEN B AND C
A IS NOT NULL
A NOT IN (B,C)
--between and 查找指定范围
select * from emp where sal between 500 and 1000;
--<=>判断是否为空
select * from emp where mgr <=> comm;
--is null 查寻空值
select * from emp where mgr is null and comm is null;
```
**7.LIKE和RLIKE**
```hive
--RLIKE可以搭配正则表达式使用
select * from emp where ename rlike '[A]';
--like模糊查询 %通配符表示任意长度任意字符
select * from emp where ename like '%A%';
```
**8.逻辑运算符**
```hive
--AND 与 OR  或 NOT 非

--查找30部门中工资大于1000的员工信息
select * from emp where sal > 1000 and deptno = 30;

--查找10和30部门的员工信息
select * from emp where deptno = 10 or deptno = 30;

--查寻不是20和30部门的员工信息
select * from emp where deptno not in(20,30);
```

**9.聚合函数**
```hive
/*
count(*) 表示统计所有行数，包含null值
count(字段) 表示该列一共有多少行，不统计null值
max() 求最大值，不统计null
min() 求最小值，不统计null
sum() 求和，不统计null
avg() 求平均值，不统计null
*/

--求10部门人数
select count(*) from emp where deptno = 10;

--求公司工资最高的员工信息
select max(sal) from emp;
```

**10.group by 分组**
group by 可以和聚合函数一起使用,对字段进行分组，然后对每个组进行聚合操作
```hive
--有where写在where后，没有where写在表名之后

--求各部门的总工资
select sum(sal) ,deptno from emp group by deptno;

--求各岗位下的最高工资
select max(sal) , job from emp group by job;
```
**11.having**
having可以对聚合函数继续过滤,写在group by之后
```hive
--求人数在三人以上的部门编号
select count(1),deptno from emp group by deptno having count(1) > 3;
```

**12.limit**
limit子句用于限制返回的行数
```hive
--显示表前五条数据
select * from emp limit 5; 
--表示从第2行开始，向下抓取3行
select * from emp limit 2,3; 
```



## **二.JOIN(多表查寻)**

**1.内连接**
满足关联条件的数据才会被显示在查寻结果集中(交集)
```hive
--关联emp表和dept表
select e.empno,e.ename,d.deptno,d.dname from emp e join dept d on e.deptno=d.deptno;
--hive支持之前oracle学的表关联语法
```

**2.左外连接**
左表为主表,显示主表所有数据,从表满足关联条件的数据显示在结果集中
```hive
select e.empno,e.ename,d.deptno,d.dname from emp e left join dept d on e.deptno=d.deptno;
```

**3.右外连接**
右表为主表,显示主表所有数据,从表满足关联条件的数据显示在结果集中
```hive
select e.empno,e.ename,d.deptno,d.dname from dept d right join emp e on e.deptno=d.deptno;
```

**4.满外关联**
显示左右两表所有的数据,即使不满足关联条件也会显示
```hive
select e.empno,e.ename,d.deptno,d.dname from emp e full join dept d on e.deptno=d.deptno;
```

**5.多表连接**
在上一个表关联条件之后,继续写关联下一张表的sql即可
```hive
select e.ename,d.dname,l.loc_name
from emp e
join dept d
on e.deptno=d.deptno
join hsstd h
on d.deptno=h.id;
```
**6.笛卡尔集**
笛卡尔集产生的条件
- 省略连接条件
- 连接条件无效
- 所有表中的所有行相互连接

```hive
select e.empno,e.ename,d.dname 
from emp e join dept d 
on 1=1;
```
