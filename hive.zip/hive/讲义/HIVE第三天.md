#                 **HIVE(第三天)**

#                         今日内容和目标

- [x] 了解集合运算(UNION)
- [x] 掌握四种排序的区别
- [x] 掌握HIVE函数的用法
- [x] 掌握HIVE分区语法结构

# **一、HIVE四种排序**

## **1.全局排序(order by)**
**order by:全局排序,只有一个reducer**

```hive
--升序(默认)ASC 
select * from emp order by sal asc;

--降序 DESC
select * from emp order by sal;

--可以使用字段别名排序，因为执行顺序在select之后
select ename,sal * 2 A from emp order by A desc;
```

## **2.每个reduce内部排序(sort by)**

**order by对数据量较大表排序时效率较低,再不需要全局排序的情况下可以使用sort by排序,sort by 排序的特点是全局无序,局部有序,会对每个reduce内的数据进行排序**

```hive
--1.查看reduce数量
set mapreduce.job.reduces;

--2.设置reduce数量
set mapreduce.job.reduces=3;

--3.根据部门编号排序查看员工信息
select * from emp sort by deptno desc;

--加载sort by结果到本地:
insert overwrite local directory
'/home/hadoop/123/sortby-result'
row format delimited fields terminated by '\t'
select * from emp sort by deptno desc;
--因为设置的reduce数量为3,所以会在目标目录下生成三个数据文件
```

## **3.分区(distribute by)**
**在有些情况下，需要控制某个特定的行进入指定reducer，为了后续的排序操作，结合sort by使用**

```hive
--查看reduce数量
set mapreduce.job.reduces;

--设置reduce数量
set mapreduce.job.reduces=3;

--对部门进行分区,再对各部门下的员工信息根据工资进行排序
select * from emp distribute by deptno sort by SAL ;

--将结果导入到linux本地
insert overwrite local directory
'/home/hadoop/123/sortby-result2'
row format delimited fields terminated by '\t'
select * from emp distribute by deptno sort by empno desc;

注意:
distribute by只有分区效果,搭配sort by才会有排序效果
如果reduce数量和distribute by分区数量不相同,会对分区字段下的值生成随机数(hash值)与reduce的个数进行相除，余数相同的分到一个区
```
## **4.分区排序(cluster by)**

当distribute by和sort by字段相同时，可以使用cluster by,并且只能升序排序

```hive
--两种写法效果相同
--1.0
select * from emp distribute by deptno sort by edptno;
--2.0
select * from emp cluster  by deptno;

--将cluster by排序结果导出到linux本地
insert overwrite local directory
'/home/hadoop/123/sortby-result3'
row format delimited fields terminated by '\t'
select * from emp cluster by deptno;
```

# **二、HIVE函数**

## **一.数字函数**
**1.四舍五入函数round**
**语法:**round(数字,保留小数后几位)

```hive
--案例
select round(13.3);
结果 13

select round(13.336,2);
结果: 13.4
```
**2.向下取整floor**
**语法:**floor(数字)

```hive
--案例
select floor(13.3);
结果: 13

select floor(13.999);
结果: 13
```
**3.向上取整ceil**
**语法:**ceil(数字)

```hive
--案例
select ceil(13.1);
结果: 14

select ceil(13.999);
结果: 14
```
**4.返回一个随机小数rand**
**语法:**rand()

```hive
--案例 
--生成一个随机小数
select rand();
结果: 0.6065231279766695

--生成一个随机整数
select round(rand()*10);
结果: 3

```

## **二.字符串函数**
**1.求字符串长度length**
**语法:**length(字符串)

```hive
--求abcd的长度
select length('abcd');
结果: 4
```
**2.反转字符串reverse**
**语法:**reverse(字符串)

```hive
--将abcd反转输出
select reverse('abcd');
结果: dcba
```
**3.字符串拼接函数concat**
**语法:**concat(字符串1,字符串2....)

```hive
select concat('a','b','c');
结果: abc
```
**4.指定分隔符拼接字符串concat_ws**
**语法:**concat_ws('分隔符',字符串1,字符串2....)

```hive
select concat_ws(';','a','b','c');
结果: 'a;b;c'
```
**5.截取函数substr**
**语法:**substr(字符串,起始位置(包含),截取长度)

```hive
--截取第一个字符
select substr('acbd',1,1);
结果: a

--截取第二个字符后所有内容 长度不写默认截取全部
select substr('abcd',2);
结果: bcd

--截取最后一个字符 (同oracle)
select substr('abcd',-1,1);
结果: d
```
**6.替换字符函数replace**
**语法:** replace(字符串,旧的值,新的值)

```hive
--案例
select replace('abcd','a','=');
结果: =bcd
```
**7.字符串转大小写upper/lower**
**语法:** 函数名(字符串)

```hive
--转大写
select upper('abcd');
结果:ABCD

--转小写
select lower('ABCD');
结果:abcd
```
**8.分割字符串函数split**
**语法:**split(字符串,分隔符) 以指定分隔符拆分字符串,返回数组

```hive
select split('abcefcth','c');
结果: ['ab' 'ef' 'th']
```

## **三.日期函数**
**1.返回当前系统日期current_date**
```hive
select current_date;
结果: 2025-04-23
```
**2.返回当前系统时间current_timestamp**
```hive
--精确到毫秒
select current_timestamp;
结果: 2025-04-23 12:12:12.304
```
**3.获取日期中的月month**
**语法:**month('日期') 返回数字

```hive
select month('2025-05-09');
结果： 5
```
**4.获取日期中的天day**
**语法:**day('日期') 

```hive
select day('2028-02-15');
结果: 15
```
**5.获取日期中的小时**
**语法:** hour('日期')

```hive
select hour('2022-04-05 13:14:15');
结果: 13
```
**6.计算日期所差天数datediff**
**语法:**datediff('日期1','日期2') 日期1减去日期2的结果

```hive
select datediff('2026-02-05','2026-02-03');
结果: 2
```
**7.日期加天数date_add**
**语法:**date_add('日期',数字)

```hive
select date_add('2025-09-08',6);
结果: 2025-09-14
```
**8.日期减天数date_sub**
**语法:**date_sub ('日期', 数字)

```hive
select date_sub('2026-07-09',2);
结果: 2026-07-07
```
**9.指定日期格式date_format**
**语法:** date_format('日期','格式')

```hive
select date_format('2026-06-06','yyyy年-mm月-dd日');
结果: 2026年-06月-06日
```

## **四.流程控制函数**

**1.case when函数**
**语法一:**  case when 条件表达式 then 返回值 else 不成立返回值 end
**注意:**  else不写默认返回空值,可以写多个when和then

```hive
--案例
select case when ename = 'SMITH' then '张三' else ename end from emp;
结果: smith显示为张三,其余保持原值不变
```
**语法二:**  case 字段名 when 判断值 then 成立返回值 else 不成立返回值 end
**注意:**  只能进行等值判断

```hive
--案例
select case ename when 'SCOTT' then '张三' 
when 'SMITH' then '李四' else ename from emp;
结果: scott显示张三smith显示李四,其余保持原值不变
```
**2.IF判断函数**
**语法:** if(条件表达式,成立返回值,不成立返回值)

```hive
--案例1
select if(1=1,'a','b');
结果: a

--案例2
select if(1=2,'a','b');
结果: b
```
## **五.集合函数**

1.创建map集合函数map

语法:map(key值,value值,key值,value值....)

注意:参数数量必须是双数 将函数中的key和value组合成map集合

```hive
--案例
select map('语文',78,'英语',13);
结果: {"语文":78,"数学":13}
```

2.提取map中的key值map_keys

语法:map_keys(map集合)

```hive
--案例
select map_keys(map('语文',78,'英语',13));
结果:["语文","英语"]
```

3.提取map中的value值map_values

语法:map_values(map集合)

```hive
--案例
select map_values(map('语文',78,'英语',13));
结果:[78,13]
```

4.声明数组类型array

语法:array(值1,值2,值3....) 根据参数生成数组类型

```hive
--案例
select array('a','b','d');
结果: ['a','b','d']
```

5.对数组内元素进行排序sort_array

```hive
--案例
select sort_array(array('a','c','b'));
结果: ['a','b','c']
```

6.生成struct类型集合函数struct

语法: struct(值1,值2,值3......)

```hive
--案例
select struct('小明','小李','小王');
结果: {"col1":"小明","col2":"小李","col3":"小王"}
```

7.声明struct属性和值函数named_struct

语法: named_struct(属性,值,属性,值...) 参数数量是双数

```hive
--案例
select named_struct('语文',13,'数学',14,'英语',16);
结果: {"语文":13,"数学":14,"英语":16}
```

## **六.聚合函数**
**1.collect_list 收集并形成list集合，结果不去重**
语法: collect_list(字段名) 可以搭配gorup by 使用 类似oracle里的wm_concat
```hive
--案例
select deptno,collect_list(ename) from emp group by deptno;
结果:
10	["CLARK","MILLER","KING"]
20	["SMITH","FORD","ADAMS","SCOTT","JONES"]
30	["ALLEN","JAMES","TURNER","BLAKE","MARTIN","WARD"]
```
**2.collect_set 收集并形成set集合，结果去重**
语法: 和collect_list一样,就多了个去重复值

## **七.开窗函数**
**1.聚合类开窗函数**

**语法:**函数名(字段名)over([partition by 字段名] [order by  字段名])

```hive
SUM() AVG() COUNT() MAX() MIN()
OVER():指定分析函数工作的数据窗口大小，这个数据窗口大小可能会随着行的变化而变化
CURRENT ROW:当前行
n PRECEDING:往前n行
n FOLLOWING:往后n行
UNBOUNDED:起点
UNBOUNDED PRECEDING：表示从前面的起点
UNBOUNDED FOLLOWING：表示从后面的起点
LAG(col,n,default_value):往前第n行数据
LEAD(col,n,default_value):往后第n行数据
```
**案例:**

```hive
SELECT DEPTNO,ENAME,HIREDATE,SAL,
      SUM(SAL) OVER() AS S1, --所有行相加
      SUM(SAL) OVER(PARTITION BY DEPTNO) AS S2, --按DEPTNO分组，组内数据相加
      SUM(SAL) OVER(PARTITION BY DEPTNO ORDER BY HIREDATE) AS S3, --按DEPTNO分组，组内数据累加
      SUM(SAL) OVER(PARTITION BY DEPTNO ORDER BY HIREDATE ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS S4, --和S3效果相同，由起点到当前行聚合
      SUM(SAL) OVER(PARTITION BY DEPTNO ORDER BY HIREDATE ROWS BETWEEN 1 PRECEDING AND CURRENT ROW) AS S5, --当前行和前面1行聚合
      SUM(SAL) OVER(PARTITION BY DEPTNO ORDER BY HIREDATE ROWS BETWEEN 1 PRECEDING AND 1 FOLLOWING) AS S6, --前1行，当前行及后1行聚合
      SUM(SAL) OVER(PARTITION BY DEPTNO ORDER BY HIREDATE ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING) AS S7 --当前行到最后一行聚合
FROM EMP;
```
**小练习:**
1.显示各部门员工的工资，并附带显示该部门的最高工资。
2.按照deptno分组，然后计算每组工资的总和
3.对各部门进行分组，并附带显示第一行至当前行的工资汇总，根据员工编号累加
当前行至最后一行的汇总，当前行的上一行(rownum-1)到当前行的汇总
当前行的上一行(rownum-1)到当前行的下两行(rownum+2)的汇总

**2.排名类开窗函数**

**语法:** 函数名()over([partition by 字段名] order by 字段名)

**注意:** over里必须有order by 

**三个排名函数的区别:**
RANK():排序相同时会重复，总数不变
DENSE_RANK():排序相同时会重复，总数会减少
ROW_NUMBER():会根据顺序计算
```hive
--案例
SELECT DEPTNO,ENAME,HIREDATE,SAL,
   RANK() OVER(PARTITION BY DEPTNO ORDER BY SAL DESC) AS RK,
   DENSE_RANK() OVER(PARTITION BY DEPTNO ORDER BY SAL DESC) AS DE_RK,
   ROW_NUMBER() OVER(PARTITION BY DEPTNO ORDER BY SAL DESC) AS ROW_RK
FROM EMP;
```
**小练习 :**
求出每个部门工资排名第二的员工信息
找出每个岗位下工资最高的人 不考虑重复情况
用emp表找出连续两年有员工入职的部门编号

# **三、分区分桶**
## **一.分区**
hive中分区就是分目录，把一个大的数据集根据业务分割成小的数据集，
在查询时通过where子句表达式选择查询所需的指定分区，这样查询效率更高。
**1.创建分区表**
注意:分区字段不能存在于表中，可以将分区字段视为伪列。
```hive
create table if not exists
dept_partition (id int,
deptno string,
dname string,
loc string)
partitioned by (day string)
row format delimited fields terminated by '\t' ;
```
**2.加载数据**
```hive
--将数据文件导入到分区表
load data local inpath
'/home/hadoop/123/dept_3.txt' into table dept_partition
partition(day='20240726');

load data local inpath
'/home/hadoop/123/dept_3.txt' into table dept_partition
partition(day='20240727');
```
**3.查看分区数据**
```hive
--查看单个分区
select * from dept_partition where day='20240727';
--使用union查看
select * from dept_partition where day='20240726'
	union
select * from dept_partition where day='20240727';
--查看多个分区数据
select * from dept_partition where day='20240726' or day='20240727';
```
**4.增加分区**
```hive
--增加单个分区
alter table dept_partition add partition(day='20240824');
--增加多个分区
alter table dept_partition add partition(day='20240823') partition(day='20240822');
```
**5.删除分区**
```hive
--删除单个分区
alter table dept_partition drop partition(day='20240822');
--删除多个分区
alter table dept_partition drop partition(day='20240823'),partition(day='20240824');
```
**6.查看分区表有多少个分区**
```hive
show partitions dept_partition;
```
**7.查看分区表结构**
```hive
desc formatted dept_partition;
```
## 二.二级分区  
**分区之后再分区,分区目录下还有分区目录,二级目录下才是数据文件**
**1.创建二级分区表**
```hive
create table if not exists
	dept_partition2 (id int,
	deptno string,
	dname string,
	loc string)
partitioned by (day string, hour string)
row format delimited fields terminated by '\t' ;
```
**2.导入数据**
```hive
load data local inpath
'/home/hadoop/123/dept_3.txt' into table dept_partition2
partition(day='20240727',hour='10');
```
**3.查询二级分区表**
```hive
select * from dept_partition2 where day='20240727' and hour='10';
```
## **三.动态分区**
**动态分区的基础概念:**
1. 关系型数据库中，对分区表insert数据时，数据库会自动根据分区字段的值，将数据插入相应的分区中，
2. hive中也提供了类似的机制，即动态分区(Dynamic Partition)，使用hive动态分区需要进行相应设置。
```hive
--动态分区准备工作
(1)开启动态分区功能(默认true，开启)
	查看set hive.exec.dynamic.partition;
(2)设置为非严格模式(默认strict，表示必须指定至少一个分区为静态分区，
nonstrict模式表示允许所有的分区字段都可以使用动态分区)
	set hive.exec.dynamic.partition.mode=nonstrict;
(3)在所有执行MR的节点上，最大一共可以创建多少个动态分区。默认1000.
	查看set hive.exec.max.dynamic.partitions;
(4)在每个执行MR的节点上，最大可以创建多少个动态分区。默认100.
	查看set hive.exec.max.dynamic.partitions.pernode;
(5)整个MR job中，最大可以创建多少个HDFS文件，默认100000
	查看set hive.exec.max.created.files;
(6)当有空分区生成时，是否抛出异常，一般不需要设置。默认false。
	查看set hive.error.on.empty.partition;
```
**1.建分区表:**
```hive
create table if not exists
dept_partition_dy (id int,
deptno string,
dname string)
partitioned by (loc string)
row format delimited fields terminated by '\t' ;
```
**2.插入动态分区**
```hive
insert into table dept_partition_dy partition(loc)
select id,deptno,dname,loc from dept_partition;
```
**3.查看目标分区表的分区情况**
```hive
show partitions dept_partition_dy;
```
## **四.分桶**
**分桶的基础概念:**
1. 分桶是将数据集分解成更容易管理的若干部分的另一个技术。
2. 分区针对的是数据的存储路径，分桶针对的是数据文件。
**1.创建分桶表**
```hive
create table if not exists
stu_buck (id int,
name string)
clustered by (id)
into 4 buckets
row format delimited fields terminated by '\t' ;
```
**2.设置reduce数量**
```hive
set mapreduce.job.reduces=-1;
```
**3.加载数据**
```hive
load data local inpath
'/home/hadoop/123/hsstd.txt' into table stu_buck;
```
**4.查看分桶表结构**
```hive
desc formatted stu_buck;
```
**5.查询分桶表数据**
```hive
select * from stu_buck;
```
注意事项：
1.reduce的个数设置为-1，让job自行决定有多少个reduce
```shell
set mapreduce.job.reduces=-1;
```
2.load数据时确定文件路径，避免找不到文件的问题
3.不要使用本地模式
```shell
set hive.exec.mode.local.auto;
```
# **四、行列转换**
**一.行转列**
```hive
concat(stringA,stringB):返回输入字符串连接后的结果，支持任意个输入字符串
concat_ws($eparator,str1,str2):是特殊形式的concat()，第一个参数是所有字符串的分隔符
collect_set(col):函数只接受基本数据类型，作用主要将某字段的值进行去重汇总，产生array类型字段
```
**1. 题目中源数据样式**
```hive
fulaoshi	白羊座	A
lilaoshi	处女座	A
chenlaoshi	白羊座	B
luolaoshi	白羊座	A
azhen	处女座	A
aqiang	白羊座	B
```
**2.题目所需数据样式**
```hive
白羊座,A	fulaoshi|luolaoshi
白羊座,B	chenlaoshi|aqiang
处女座,A	lilaoshi|azhen
```
**3.建表语句**
```hive
create table if not exists
hstc (name string,
constellation string,
blood_type string)
row format delimited fields terminated by '\t' ;
```
**4.导入数据**
```hive
load data local inpath
'/home/hadoop/123/hstc.txt' into table hstc;
```
**5.HQL语句**
```hive
select t1.c_b,concat_ws('|',collect_set(t1.name)) name_lt
from
(select name,concat_ws(',',constellation,blood_type) c_b from hstc) t1
group by t1.c_b;
```
**二.列转行**
```hive
explode(col):将hive中一列复杂的array或者map结构拆分成多行
lateral view
用法：lateral view udtf(expression) tableAlias AS columnAlias
解释：用于和split explode等UDTF函数一起使用，它能将一列数据拆成多行数据，在此基础上可以对拆分后的数据进行聚合
```
**1. 题目中源数据样式**
```hive
教父	黑帮,警匪,心理,剧情
侏罗纪公园	动作,科幻,剧情,灾难
战狼	战争,动作,灾难
```
**2. 题目所需数据样式**
```hive
教父	黑帮
教父	警匪
教父	心理
教父	剧情
侏罗纪公园	动作
侏罗纪公园	科幻
侏罗纪公园	剧情
侏罗纪公园	灾难
战狼	战争
战狼	动作
战狼	灾难
```
**3.建表语句**

```hive
create table if not exists
movie_info (movie string,
category string)
row format delimited fields terminated by '\t' ;
```
**4.导入数据**
```hive
load data local inpath
'/home/hadoop/123/movie.txt' into table movie_info;
```
**5.HQL语句：**
```hive
select movie,category_name
from movie_info
lateral view
explode(split(category,',')) movie_info_tmp as category_name;
```